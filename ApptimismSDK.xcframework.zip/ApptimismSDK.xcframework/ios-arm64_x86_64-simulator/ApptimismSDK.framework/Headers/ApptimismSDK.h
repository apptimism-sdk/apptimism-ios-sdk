//
//  ApptimismSDK.h
//  ApptimismSDK
//
//  Created by DaniyalDevetov on 02/04/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for ApptimismSDK.
FOUNDATION_EXPORT double ApptimismSDKVersionNumber;

//! Project version string for ApptimismSDK.
FOUNDATION_EXPORT const unsigned char ApptimismSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ApptimismSDK/PublicHeader.h>


